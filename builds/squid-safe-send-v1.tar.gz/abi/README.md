# ABI folder

This is a dedicated folder for ABI files. Place your contract ABI here and generate facade classes for type-safe decoding of the event data and contract state queries with

```sh
sqd typegen
```

This `typegen` command is defined in `commands.json`.
